# Confessions Commenter

Easily autogenerate comments for facebook posts!